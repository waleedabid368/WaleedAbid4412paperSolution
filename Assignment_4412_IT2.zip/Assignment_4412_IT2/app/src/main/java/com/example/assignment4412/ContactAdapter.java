package com.example.assignment4412;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {
    private Context context;
    private List<Contact> contacts;
    private LayoutInflater layoutInflater;

    public ContactAdapter(Context context, List<Contact> contacts) {
        this.context = context;
        this.contacts = contacts;
        this.layoutInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ContactAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.item_contact, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactAdapter.ViewHolder holder, int position) {
        holder.layoutContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context.getApplicationContext(), ShowCallInfoActivity.class);
                intent.putExtra("CATEGORY", contacts.get(position).getCategory());
                intent.putExtra("NUMBER", contacts.get(position).getNumber());
                context.startActivity(intent);
            }
        });
        holder.imgIcon.setImageResource(contacts.get(position).getResID());
        holder.txtCategory.setText(contacts.get(position).getCategory());
        holder.txtNumber.setText(contacts.get(position).getNumber());
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private MaterialCardView layoutContact;
        private ImageView imgIcon;
        private TextView txtCategory, txtNumber;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            layoutContact = itemView.findViewById(R.id.layoutContact);
            imgIcon = itemView.findViewById(R.id.imgIcon);
            txtCategory = itemView.findViewById(R.id.txtCategory);
            txtNumber = itemView.findViewById(R.id.txtNumber);
        }
    }
}