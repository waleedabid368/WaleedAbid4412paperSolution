package com.example.assignment4412;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ShowCallInfoActivity extends AppCompatActivity {
    private TextView txtCategory, txtNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_call_info);

        txtCategory = findViewById(R.id.txtCategory);
        txtNumber = findViewById(R.id.txtNumber);

        txtCategory.setText(getIntent().getExtras().getString("CATEGORY"));
        txtNumber.setText(getIntent().getExtras().getString("NUMBER"));
    }
}